package com.example.SOAPwebService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoaPwebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoaPwebServiceApplication.class, args);
	}

}
