package com.example.SOAPwebService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoaPwebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
